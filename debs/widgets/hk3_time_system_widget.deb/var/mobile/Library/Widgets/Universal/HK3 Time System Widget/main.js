const main = {
    time : document.getElementById('time').children,
    date : document.getElementById('date').children,
}
const dateOptions = {
    weekday : 'short',
    month : 'short',
    day : 'numeric',
    hour12 : true
}

function zeroPadTwoDigits(value) {
    return value < 10 ? `0${value}`:value.toString()
}

function updateTime() {
    const date = new Date()
    main.time[0].innerText = `${zeroPadTwoDigits(date.getHours()%12)}:${zeroPadTwoDigits(date.getMinutes())}`
    main.time[1].innerText = date.getHours() >= 12 ? 'PM' : 'AM'
    const dateText = date.toLocaleDateString('en-US', dateOptions)
    main.date[0].innerText = `${dateText.split(',')[0]},`
    main.date[1].innerText = dateText.split(',')[1]
}

updateTime()
setInterval(updateTime, 1000)

function getBarSegments(eBar) {
    const tracks = [...eBar.children]
    return tracks.map((track) => track.children[0])
}

function updateBarSegments(segments, percentage) {
    const segmentFill = 100 / segments.length
    const nFilledSegments = Math.floor(percentage / segmentFill)
    const partialSegementFill = (percentage - nFilledSegments * segmentFill) / segmentFill * 100
    let i = 0
    for (i=0;i<nFilledSegments;i++)
        segments[i].style.width = '100%'
    if (i<segments.length)
        segments[i].style.width = `${partialSegementFill}%`, i++
    for (;i<segments.length;i++)
        segments[i].style.width = '0'
}

const cpu = {
    barSegments: getBarSegments(document.getElementById('cpu-bar'))
}

const battery = {
    currentLabel: document.getElementById('battery-level'),
    barSegments: getBarSegments(document.getElementById('battery-bar'))
}

const ram = {
    currentLabel: document.getElementById('ram-level'),
    maxLabel: document.getElementById('ram-max'),
    bar: document.getElementById('ram-bar')
}

api.resources.observeData((data) => {
    // CPU
    updateBarSegments(cpu.barSegments, data.processor.load)
    // Battery
    battery.currentLabel.innerText = data.battery.percentage
    updateBarSegments(battery.barSegments, data.battery.percentage)
    // RAM
    ram.currentLabel.innerText = data.memory.used
    ram.maxLabel.innerText = `${data.memory.available}MB`
    ram.bar.style.width = `${data.memory.used / data.memory.available * 100}%`
})